FINAL RELEASE — CRAIG WHITSON WORLD CUP COMPANION

Upload every file in this folder to the root of:
https://github.com/craigwhitson/SA55IMC-Craigs-WorldCup

Replace the existing files and commit directly to main.

Then open:
https://craigwhitson.github.io/SA55IMC-Craigs-WorldCup/?release=1

This final version:
- uses the approved premium South Africa IMC layout;
- includes the selected playing-shirt portrait and authentic SA Masters Hockey badge;
- uses the quote with “loved ones”;
- removes the message board and all Firebase code;
- keeps Photos and Journal private to each device;
- retains fixtures, results, maps, countdown and calendar;
- works on iPhone, iPad, Android and desktop.
